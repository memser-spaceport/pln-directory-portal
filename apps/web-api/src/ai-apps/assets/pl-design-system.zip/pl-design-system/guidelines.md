# Design System Guidelines for AI Agents

## Core Rule

---

## Forbidden Behavior

Do NOT do any of the following:

- Recreate components manually using raw HTML/CSS/JSX
- Flatten or redraw icons
- Draw custom buttons, cards, inputs, badges, modals, tabs, tables, dropdowns, or sidebars
- Hardcode colors, typography, radius, shadows, spacing, or borders — always use tokens
- Use page screenshots as component sources
- Use product page examples as primitive sources
- Approximate a missing component — stop and report instead

---

## Retrieval Order

When generating UI, retrieve components in this order:

1. **Primitive Components** — Button, Input, Badge, Checkbox, etc.
2. **Product / Composite Components** — Cards, Headers, Sidebars, etc.
3. **Layout Patterns** — Grid, Sidebar, Stack, etc.
4. **Page Examples** — structural reference only
5. **Foundations / Styles** — only when assembling layout that needs tokens directly

---

## Missing Component Behavior

1. Stop generation
2. Do not approximate or invent
3. Output exactly:

```
```

Then ask for confirmation before proceeding.

---

## Token Usage

All visual values must come from the token system:

| Value type | Source |
|---|---|
| Colors | `--foreground-*`, `--background-*`, `--border-*` tokens |
| Typography | `--type-*` tokens or `@include mixins.*` |
| Spacing | `--spacing-*` tokens |
| Radius | `--radius-*` tokens |
| Shadows | `--shadow-*` tokens |
| Z-index | `--z-*` tokens |

Never use raw hex values, pixel hardcodes, or Tailwind class names.

---

## Component Instantiation Rules

- Preserve auto-layout and spacing behavior
- Do not modify a component's internal structure when instantiating
- Do not add decorative elements not present in the canonical component

---

## Hierarchy Rules

- Only one primary CTA per section
- Navigation must use canonical nav components — do not compose custom nav
- Cards are product components — do not use generic `div` containers for card layouts
- Overlays (Modal, Drawer, Bottom Sheet) must use canonical overlay components

---

## Typography Hierarchy

- **In-platform page H1 = `heading-md-strong` (32px, weight 600).** Use it for the primary title of any page inside the platform (directories, profiles, detail views, settings, dashboards).
- **`heading-lg` (40px) and larger** (`heading-2xl`, `heading-3xl`, `display`) are reserved for **landing / marketing pages**, not in-product page headers.
- Step down from the page H1 with `heading-sm` for section titles and the `label-*` / `body-*` scales for everything else.

---

## Visual Language

Protocol Labs UI must feel: structured · calm · technical · modular · minimal · trustworthy · infrastructure-like.

Avoid: crypto aesthetics · speculative-finance UI · excessive gradients · glow effects · noisy SaaS dashboards · decorative heavy shadows · over-rounded consumer UI · random accent colors · visual novelty.
