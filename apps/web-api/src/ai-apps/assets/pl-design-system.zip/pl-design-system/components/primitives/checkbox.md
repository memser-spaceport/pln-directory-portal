# Checkbox Component

---

## Purpose

Allow users to select one or multiple options. Also includes Radio button controls.

---

## Important: Radio buttons live here

The Checkbox page contains both **Checkbox** and **Radio** controls as a shared Type property. There is no separate "Radio Button" page.

---

## Sub-components

### Checkbox (control only)

The bare control without label.

**Variant** (check state):
- `Unchecked`
- `Checked`
- `Minus-Indeterminate` (partial group selection)

**Type** (shape):
- `Checkbox` — square/rounded-square control
- `Radio` — circular control

**State**:
- `Normal`
- `Hover`
- `Focus`
- `Disable`

**Size**:
| Value | Control size |
|---|---|
| Medium | 24×24px |
| Large | 28×28px |

---

### Checkbox Label (selectable row)

The control with an attached label. This is what appears in forms.

**Variant**: Unchecked, Checked, Minus-Indeterminate
**State**: Normal, Hover, Focus, Disable
**Size**:
| Value | Row height |
|---|---|
| Small | 62px |
| Medium | 74px |
| Large | 83px |

---

## Checkbox Group

See separate spec: [`checkbox-group.md`](./checkbox-group.md)

---

## Usage Rules

1. Use `Checkbox Label` for form contexts — not the bare Checkbox control
2. Use `Radio` type for mutually exclusive choices; use `Checkbox` type for multi-select
3. Use `Minus-Indeterminate` for partial group selection (e.g., "select all" parent)
4. Never manually recreate checkbox or radio styling

---

## AI Instructions

- Use `Checkbox Label` rows in forms, not just the bare control
- Preserve focus states for accessibility
