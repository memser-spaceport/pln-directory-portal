# Badges & Tags Component

---

## Purpose

Badges communicate status, category, metadata, role, and lightweight system meaning. Badge Dots indicate presence, activity, or notification count.

---

## Sub-components

### Badge

| Property | Values |
|---|---|
| **Color** | Blue (Brand), Gray (Neutral), Green (Success), Yellow (Warning), Red (Error) |
| **Style** | Light, Outline, Fill |
| **Size** | Small (16px h), Medium (20px h), **Large (24px h) — component default** |
| **Disable** | False, True |

> **React defaults:** `color="blue"`, `styleType="light"`, **`size="lg"`**. The default size is Large (changed from Medium); pass `size="sm"` / `"md"` for denser contexts.

> - Blue → Brand/Primary
> - Gray → Neutral
> - Green → Success
> - Yellow → Warning
> - Red → Error/Danger

**Style guide:**
- `Light` — subtle fill, low visual weight; use for categories and metadata
- `Outline` — bordered, no fill; use for interactive filters and toggleable tags
- `Fill` — solid fill; use for critical status, active states, high-emphasis labels

---

### Implementation reference (Figma-accurate)

**Box model** — height comes from the label line-height + vertical padding (not a collapsed `line-height`). Label weight is **Medium (500)** — Figma "Label/…/strong" — not semibold.

| Size | Height | Font (mixin) | Line-height | H-padding | Gap |
|---|---|---|---|---|---|
| Small | 16px | `label-xs` (12px) | 16px | 6px | 0 |
| Medium | 20px | `label-xs` (12px) | 16px | 8px | 2px |
| Large | 24px | `label-sm` (14px) | 20px | 10px | 2px |

**Color tokens per style** (Layer-3 only — see `pl-design-tokens`):

| Color | Light (bg / text) | Outline (border / text) | Fill (bg / text) |
|---|---|---|---|
| Blue | `--background-brand-light-solid` / `--foreground-brand-secondary-inv` | `--border-brand-subtle` / `--foreground-brand-secondary-inv` | `--background-brand-default` / `--foreground-light-primary` |
| Gray | `--background-neutral-light-solid` / `--foreground-neutral-secondary` | `--border-neutral-muted` / `--foreground-neutral-secondary` | `--background-neutral-default` / `--foreground-light-primary` |
| Green | `--background-success-light-solid` / `--foreground-success-secondary` | `--border-success-subtle` / `--foreground-success-secondary` | `--background-success-normal` / `--foreground-light-primary` |
| Yellow | `--background-warning-light-solid` / `--foreground-warning-primary` | `--border-warning-subtle` / `--foreground-warning-primary` | `--background-warning-strong` / `--foreground-light-primary` |
| Red | `--background-error-light-solid` / `--foreground-error-secondary` | `--border-error-subtle` / `--foreground-error-secondary` | `--background-error-normal` / `--foreground-light-primary` |

**Light fills are opaque (100%).** The `--background-<hue>-light-solid` tokens are the transparent tints (`--transparent-*`) flattened over white — visually identical on a white card, but render consistently over any backdrop.

New Layer-3 tokens added for exact Figma fidelity: the five `--background-<hue>-light-solid` opaque light fills, plus `--background-neutral-default` (slate-500 fill-gray), `--background-warning-strong` (amber-600 fill-yellow), `--border-success-subtle`, `--border-warning-subtle`, `--border-error-subtle`.

---

### Badge Dot (_BaseBadgeDot)

| Property | Values |
|---|---|
| **Color** | Light, Light Secondary, Blue, Green, Yellow, Red |
| **Size** | Small (12px), Medium (16px), Large (16–24px) |

Use Badge Dots for presence indicators, online status, and notification indicators.

---

## Usage

Use badges for:
- Member roles and focus areas
- Content categories
- Availability status (e.g., "Available to connect", "Frequently Booked")
- Filter chips and active filter indicators
- Lightweight metadata on cards

---

## Rules

1. Use semantic colors — never custom colors
2. Limit to 1–3 badges per card or list item
3. Do not use oversized badges for primary content — they are metadata
4. Gray badges are for secondary/neutral states
5. "Disable=True" variant must be used for non-interactive disabled states

---

## AI Instructions

- Never draw custom pill or tag shapes
- Preserve Disable variants when rendering non-interactive badges
