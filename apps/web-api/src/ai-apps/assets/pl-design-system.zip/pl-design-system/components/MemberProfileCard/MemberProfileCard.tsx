import clsx from 'clsx';
import type { MemberProfileCardProps } from './MemberProfileCard.types';
import styles from './MemberProfileCard.module.scss';
import { Avatar } from '@components/Avatar';
import { Badge } from '@components/Badge';

const availabilityLabel: Record<string, string> = {
  available:   'Available to connect',
  booked:      'Frequently Booked',
  unavailable: 'Not available',
};

const MapPinIcon = () => (
  <svg className={styles.locationIcon} viewBox="0 0 16 16" fill="none" aria-hidden="true">
    <path d="M8 1.5a5 5 0 0 1 5 5c0 3.3-5 8-5 8s-5-4.7-5-8a5 5 0 0 1 5-5Z"
      stroke="currentColor" strokeWidth="1.2"/>
    <circle cx="8" cy="6.5" r="1.7" fill="currentColor"/>
  </svg>
);

// Card-level decoration — NOT part of the Avatar primitive.
// Rings are centred at SVG point (75, 73.5), which maps to the avatar
// centre (banner bottom edge) once positioned in the banner.
const DecorativeRings = () => (
  <svg
    className={styles.rings}
    width="150" height="147"
    viewBox="0 0 150 147"
    fill="none"
    aria-hidden="true"
    focusable="false"
  >
    <ellipse cx="75" cy="73.5" rx="74" ry="72.5"
      stroke="var(--transparent-brand-6)" strokeWidth="1" />
    <circle  cx="75" cy="73.5" r="52"
      stroke="var(--transparent-brand-8)" strokeWidth="1.5" />
  </svg>
);

export function MemberProfileCard({
  name, role, company, location, tags = [], tagSize = 'lg',
  avatar, availability, href, className, ...props
}: MemberProfileCardProps) {
  const Tag = href ? 'a' : 'div';

  return (
    <Tag
      href={href}
      className={clsx(styles.root, className)}
      {...props as any}
    >
      {/* ── Banner: gradient + rings + avatar (avatar sits inside the band) ── */}
      <div className={styles.banner}>
        <DecorativeRings />
        <div className={styles.avatarWrap}>
          <Avatar name={name} src={avatar} size="2xl" shape="circle" aria-label="" />
        </div>
      </div>

      {/* Availability pill straddles the banner/content boundary */}
      {availability && (
        <span className={clsx(styles.pill, styles[availability])}>
          {availabilityLabel[availability]}
        </span>
      )}

      {/* ── Content ─────────────────────────────────────────────────────── */}
      <div className={styles.content}>
        <div className={styles.name}>{name}</div>

        {(company || role) && (
          <div className={styles.meta}>
            {company && <span className={styles.company}>{company}</span>}
            {role && <span className={styles.role}>{role}</span>}
          </div>
        )}

        {location && (
          <div className={styles.location}>
            <MapPinIcon />
            {location}
          </div>
        )}

        {tags.length > 0 && (
          <div className={styles.tags}>
            {tags.map(tag => (
              <Badge key={tag} color="gray" styleType="light" size={tagSize}>{tag}</Badge>
            ))}
          </div>
        )}
      </div>
    </Tag>
  );
}
