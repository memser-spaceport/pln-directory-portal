# Jobs Cards

Status: TODO verify exact variant names via MCP

---

## Purpose

Job listing preview cards on the Job Board page.

---

## Anatomy

- Company logo or avatar
- Company name
- Role title (primary)
- Location (remote/on-site/hybrid + region)
- Job type badge (Full-time, Part-time, Contract)
- Compensation (if provided)
- Tags: skills, tech stack (canonical Badges & Tags)
- Apply or Save action

---

## Rules

- Role title is the primary element
- Location and type are secondary metadata
- Tags are tertiary — keep to 3–4 max
- Apply action uses canonical Button

---

## AI instruction

```
```
