# Table Cells

---

## Variant dimensions

Each cell symbol combines:

- **Type** — content pattern (text, avatar+details, toggles, badges, progress, chart, flags, checkbox, actions, etc.)
- **Background** — `White`, `Light gray`
- **State** — `Default`, `Hover`, `Active`

---

## Rules

- Pick the **Type** that matches the data column — do not use `Regular text` when `Avatar + details` or `Status badge` exists.

---

## AI instruction

```
```

For full tables, see [table.md](./table.md).
