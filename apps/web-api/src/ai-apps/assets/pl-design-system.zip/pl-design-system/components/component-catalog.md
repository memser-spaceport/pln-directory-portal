# Component Catalog

All design system components for PL Network / LabOS, grouped by category. Each entry
links to its React implementation under `components/` and its usage doc.

---

## Primitive Components

| Component | Code | Spec |
|---|---|---|
| Button | `components/Button/` | [buttons.md](./primitives/buttons.md) |
| Input | `components/Input/` | [inputs.md](./primitives/inputs.md) |
| TextArea | `components/Textarea/` | [textarea.md](./primitives/textarea.md) |
| Checkbox + Radio | `components/Checkbox/` | [checkbox.md](./primitives/checkbox.md) |
| Checkbox Group | `components/CheckboxGroup/` | [checkbox-group.md](./primitives/checkbox-group.md) |
| Badges & Tags | `components/Badge/` | [badges-tags.md](./primitives/badges-tags.md) |
| Accordion | `components/Accordion/` | [accordion.md](./primitives/accordion.md) |
| Dropdown | `components/Dropdown/` | [dropdown.md](./primitives/dropdown.md) |
| Empty States | `components/EmptyState/` | [empty-states.md](./primitives/empty-states.md) |
| Pagination | `components/Pagination/` | [pagination.md](./primitives/pagination.md) |
| Progress | `components/Progress/` | [progress.md](./primitives/progress.md) |
| Regular Search Input | `components/SearchInput/` | [search-input.md](./primitives/search-input.md) |
| Switch & Toggle | `components/Switch/` | [switch-toggle.md](./primitives/switch-toggle.md) |
| Tabs | `components/Tabs/` | [tabs.md](./primitives/tabs.md) |
| Tooltips | `components/Tooltip/` | [tooltips.md](./primitives/tooltips.md) |
| Context Menu | `components/ContextMenu/` | [context-menu.md](./primitives/context-menu.md) |
| Date Picker | _(planned)_ | [date-picker.md](./primitives/date-picker.md) |
| Slider / Range | `components/Slider/` | [slider.md](./primitives/slider.md) |
| Steps | `components/Steps/` | [steps.md](./primitives/steps.md) |
| Carousel | `components/Carousel/` | [carousel.md](./primitives/carousel.md) |
| Table | `components/Table/` | [table.md](./primitives/table.md) |

---

## Composite Components

| Component | Code | Spec |
|---|---|---|
| Header & Nav | `components/NavBar/` | [header-navigation.md](./product/header-navigation.md) |
| Bottom Navigation | `components/BottomNav/` | [header-navigation.md](./product/header-navigation.md) |
| Sidebars & Bottom Sheets | `components/Sidebar/` | [sidebars-drawers.md](./product/sidebars-drawers.md) |
| Cards (all types) | `components/*Card/` | [cards.md](./product/cards.md) |
| Modals | _(planned)_ | — |
| Drawer | `components/Drawer/` | [sidebars-drawers.md](./product/sidebars-drawers.md) |
| Alerts & Notification | `components/Alert/`, `components/Notification/` | [alerts-notifications.md](./primitives/alerts-notifications.md) |
| Upload | `components/Upload/` | [file-upload.md](./primitives/file-upload.md) |

---

## Key Organization Notes

1. **Bottom Navigation** lives in `components/BottomNav/`; the desktop header is `components/NavBar/`.

2. **Comments** are documented within the cards spec ([cards.md](./product/cards.md)).

3. **Checkbox includes Radio buttons** — Radio is a variant of the Checkbox component.

4. **Upload** contains the upload primitives (File Upload Area, Image Upload, File Upload Status).

5. **Regular Search Input is separate from Input** — use `components/SearchInput/` for search; the main `Input` has no search variant.

6. **Input styles are Rounded and Fill** — not "Default", "Underline", or "Filled".

7. **Badge colors are Blue/Gray/Green/Yellow/Red** — mapping to semantic roles: Blue→Brand, Gray→Neutral, Green→Success, Yellow→Warning, Red→Error.

---

## Foundations

| Foundation | Source |
|---|---|
| Colors | `tokens/colors.scss` |
| Typography | `tokens/typography.scss` |
| Spacing / radius / shadows | `tokens/spacing.scss` |
