'use client';

import clsx from 'clsx';
import { X, CaretRight } from '@phosphor-icons/react';
import { Button } from '../Button';
import { Avatar } from '../Avatar';
import { Progress } from '../Progress';
import type { NotificationProps } from './Notification.types';
import styles from './Notification.module.scss';

/**
 * Notification — toast-style notification card.
 */
export function Notification({
  type = 'small-image',
  title,
  supportingText,
  image,
  avatarName,
  avatarSrc,
  logo,
  progress,
  primaryAction,
  secondaryAction,
  onClose,
  className,
  ...props
}: NotificationProps) {
  const hasActions = primaryAction || secondaryAction;

  const actions = hasActions ? (
    <div className={styles.actions}>
      {primaryAction && (
        <Button
          variant="primary"
          styleType="fill"
          size="sm"
          rightIcon={<CaretRight size={18} weight="bold" />}
          fullWidth={type === 'large-image'}
          onClick={primaryAction.onClick}
        >
          {primaryAction.label}
        </Button>
      )}
      {secondaryAction && (
        <Button
          variant="neutral"
          styleType="border"
          size="sm"
          fullWidth={type === 'large-image'}
          onClick={secondaryAction.onClick}
        >
          {secondaryAction.label}
        </Button>
      )}
    </div>
  ) : null;

  const closeButton = onClose ? (
    <button
      type="button"
      className={styles.close}
      aria-label="Dismiss notification"
      onClick={onClose}
    >
      <X size={20} weight="bold" />
    </button>
  ) : null;

  const text = (
    <div className={styles.text}>
      <p className={styles.title}>{title}</p>
      {supportingText && <p className={styles.supporting}>{supportingText}</p>}
    </div>
  );

  const leading = (() => {
    if (type === 'avatar') {
      return <Avatar name={avatarName ?? ''} src={avatarSrc} size="xl" />;
    }
    if (type === 'logo') {
      return <span className={styles.logoCircle}>{logo}</span>;
    }
    return null;
  })();

  const rootClass = clsx(styles.root, styles[`type-${type}`], className);

  // Large image — full-bleed banner on top, then content, then full-width actions
  if (type === 'large-image') {
    return (
      <div className={rootClass} {...props}>
        {image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img className={styles.banner} src={image} alt="" />
        )}
        <div className={styles.body}>{text}</div>
        {actions && <div className={styles.actionBar}>{actions}</div>}
        {closeButton}
      </div>
    );
  }

  // Small image — thumbnail to the left of content
  if (type === 'small-image') {
    return (
      <div className={rootClass} {...props}>
        {image && (
          // eslint-disable-next-line @next/next/no-img-element
          <img className={styles.thumb} src={image} alt="" />
        )}
        <div className={styles.content}>
          {text}
          {actions}
        </div>
        {closeButton}
      </div>
    );
  }

  // Avatar / Logo — leading visual on top, stacked content
  return (
    <div className={rootClass} {...props}>
      {leading}
      <div className={styles.content}>
        {text}
        {type === 'logo' && progress && (
          <Progress
            value={progress.value}
            label={progress.label}
            showValue
            size="md"
          />
        )}
        {actions}
      </div>
      {closeButton}
    </div>
  );
}
