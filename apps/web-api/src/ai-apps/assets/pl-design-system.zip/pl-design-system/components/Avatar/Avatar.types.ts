// Avatar component types
// File: apsV3GKbIbOSpZYGvhdKqU

// ─── Size ─────────────────────────────────────────────────────────────────────
//
export type AvatarSize = 'xs' | 'sm' | 'md' | 'lg' | 'xl' | '2xl' | '3xl';

// ─── Shape ────────────────────────────────────────────────────────────────────
//             xs/sm=4px, md=6px, lg=8px, xl/2xl=12px, 3xl=16px
export type AvatarShape = 'circle' | 'rounded';

// ─── Type ─────────────────────────────────────────────────────────────────────
// Default inference: src present → 'image'; no src → 'letter-of-name'.
// On image load error, 'image' falls back to 'letter-of-name' automatically.
export type AvatarType =
  | 'image'          // actual photo; falls back to letter-of-name on error
  | 'placeholder'    // brand-blue bg + white person silhouette
  | 'letter-of-name' // brand-blue bg + white initials (first + last initial)
  | 'brand-logo'     // org/company icon — provide via `icon` prop
  | 'emoji'          // emoji image — provide via `icon` prop
  | 'flag';          // country flag — provide via `icon` prop

// ─── Props ────────────────────────────────────────────────────────────────────
// NOTE: presence dot (AvatarPresenceStatus / online-status dot) was removed.
// Routing availability status through Avatar is tracked as a future Phase 2.2 commit.

export interface AvatarProps {
  /** Full name — used for initials (first + last initial) and default aria-label */
  name: string;
  /** Photo URL. When provided, type defaults to 'image'. Falls back to 'letter-of-name' on error. */
  src?: string;
  /**
   * Content type. If omitted: 'image' when src is present, 'letter-of-name' otherwise.
   * For 'brand-logo' | 'emoji' | 'flag', pass content via the `icon` prop.
   */
  type?: AvatarType;
  /** Custom content for brand-logo, emoji, flag types */
  icon?: React.ReactNode;
  size?: AvatarSize;
  shape?: AvatarShape;
  /**
   * Top-right badge slot — for Verified, Logo, Notification indicators.
   */
  topBadge?: React.ReactNode;
  /**
   * Bottom-center badge slot — for card-level badges.
   * Positioned at top: 100%; left: 50%; transform: translateX(-50%).
   */
  bottomBadge?: React.ReactNode;
  /**
   * Renders the two decorative concentric rings (inner 106px + outer 150px).
   */
  decorativeRing?: boolean;
  className?: string;
  'aria-label'?: string;
}

export interface AvatarStackProps {
  children: React.ReactNode;
  /**
   * Overlap between adjacent avatars.
   * 'auto' (default) = round(sizePx × 0.3).
   * Numeric value overrides in px — use negative values to add spacing instead.
   */
  gap?: number | 'auto';
  /** Show only the first N avatars; render overflow pill for the rest */
  maxVisible?: number;
  /** Explicit overflow count — auto-computed from children.length when omitted */
  overflow?: number;
  /** Should match the size prop of the child Avatar components */
  size?: AvatarSize;
  /** Should match the shape prop of the child Avatar components */
  shape?: AvatarShape;
  className?: string;
}
