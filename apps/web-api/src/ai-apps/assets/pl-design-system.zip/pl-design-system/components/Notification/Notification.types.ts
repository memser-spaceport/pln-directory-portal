import type { HTMLAttributes, ReactNode } from 'react';

// Basic notification — frame 15295:43746
//
//   Small image → 'small-image' (450w, thumbnail left)
//   Avatar      → 'avatar'      (300w, avatar on top)
//   Logo        → 'logo'        (300w, logo on top, optional progress)
//   Large image → 'large-image' (320w, full-bleed image on top)

export type NotificationType =
  | 'small-image'
  | 'avatar'
  | 'logo'
  | 'large-image';

export interface NotificationAction {
  label: ReactNode;
  onClick?: () => void;
}

export interface NotificationProps extends HTMLAttributes<HTMLDivElement> {
  type?: NotificationType;
  title: ReactNode;
  supportingText?: ReactNode;

  /** Thumbnail / banner image URL for 'small-image' and 'large-image'. */
  image?: string;
  /** For 'avatar' type — forwarded to Avatar. */
  avatarName?: string;
  avatarSrc?: string;
  /** For 'logo' type — logo/icon node shown in the leading circle. */
  logo?: ReactNode;

  /** For 'logo' type — render an inline progress bar. */
  progress?: { value: number; label?: string };

  /** Primary (filled) action. */
  primaryAction?: NotificationAction;
  /** Secondary (bordered) action. */
  secondaryAction?: NotificationAction;

  /** Show the close button and handle dismissal. */
  onClose?: () => void;
}
