# File Upload

---

## File Upload Area (`15147:12240`)

- **Size**: Large (440×240), Small (500×80)
- **State**: Default, Hover

---

## Image Upload (`15147:12322`)

- **Property**: Default, Uploaded

---

## File Upload Status (`15147:12371`)

---

## Rules

- Compose upload flows with these instances plus canonical **Progress** where needed.
- Do not build drag-and-drop zones from scratch.

---

## AI instruction

```
```
