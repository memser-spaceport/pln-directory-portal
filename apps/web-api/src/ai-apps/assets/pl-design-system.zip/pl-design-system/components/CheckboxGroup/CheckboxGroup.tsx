'use client';

import { useId, useState, type KeyboardEvent } from 'react';
import clsx from 'clsx';
import { Info } from '@phosphor-icons/react';
import { Checkbox } from '../Checkbox';
import { Avatar } from '../Avatar';
import type { CheckboxGroupProps } from './CheckboxGroup.types';
import styles from './CheckboxGroup.module.scss';

/**
 * CheckboxGroup — a selectable row or card that wraps a Checkbox control.
 * The whole surface is the interactive target (role="checkbox"); the inner
 * Checkbox is presentational.
 */
export function CheckboxGroup({
  type = 'basic',
  size = 'md',
  checkboxPosition = 'right',
  checked,
  defaultChecked = false,
  onChange,
  disabled = false,
  label,
  supportingText,
  subLabel,
  badge,
  info = false,
  icon,
  avatarName,
  avatarSrc,
  image,
  price,
  priceCaption,
  id,
  className,
  ...props
}: CheckboxGroupProps) {
  const generatedId = useId();
  const rowId = id ?? generatedId;

  const isControlled = checked !== undefined;
  const [internal, setInternal] = useState(defaultChecked);
  const isChecked = isControlled ? checked : internal;

  const toggle = () => {
    if (disabled) return;
    const next = !isChecked;
    if (!isControlled) setInternal(next);
    onChange?.(next);
  };

  const onKeyDown = (e: KeyboardEvent<HTMLDivElement>) => {
    if (e.key === ' ' || e.key === 'Enter') {
      e.preventDefault();
      toggle();
    }
  };

  const control = (
    <span className={styles.controlSlot} aria-hidden>
      <Checkbox
        size="lg"
        checked={isChecked}
        onCheckedChange={() => {}}
        disabled={disabled}
        tabIndex={-1}
      />
    </span>
  );

  const leading = (() => {
    switch (type) {
      case 'with-icon':
        return icon ? <span className={styles.iconCircle}>{icon}</span> : null;
      case 'with-logo':
        return icon ? <span className={styles.logoBox}>{icon}</span> : null;
      case 'avatar':
        return <Avatar name={avatarName ?? ''} src={avatarSrc} size="lg" />;
      case 'with-image':
        return image ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img className={styles.thumb} src={image} alt="" />
        ) : null;
      default:
        return null;
    }
  })();

  const titleRow = (
    <div className={styles.title}>
      <span className={styles.label}>{label}</span>
      {subLabel && <span className={styles.subLabel}>{subLabel}</span>}
      {badge && <span className={styles.badgeSlot}>{badge}</span>}
      {info && <Info className={styles.infoIcon} size={20} aria-hidden />}
    </div>
  );

  const rootProps = {
    id: rowId,
    role: 'checkbox' as const,
    'aria-checked': isChecked,
    'aria-disabled': disabled || undefined,
    tabIndex: disabled ? -1 : 0,
    onClick: toggle,
    onKeyDown,
    className: clsx(
      styles.root,
      styles[`type-${type}`],
      type === 'basic' && styles[`size-${size}`],
      isChecked && styles.selected,
      disabled && styles.disabled,
      className,
    ),
    ...props,
  };

  // Card type — header (icon + label + checkbox) over a body (price + description)
  if (type === 'card') {
    return (
      <div {...rootProps}>
        <div className={styles.cardHeader}>
          {icon && <span className={styles.iconCircle}>{icon}</span>}
          <span className={styles.label}>{label}</span>
          {control}
        </div>
        <div className={styles.cardBody}>
          {(price || badge) && (
            <div className={styles.priceRow}>
              {price && <span className={styles.price}>{price}</span>}
              {priceCaption && <span className={styles.priceCaption}>{priceCaption}</span>}
              {badge && <span className={styles.badgeSlot}>{badge}</span>}
            </div>
          )}
          {supportingText && <p className={styles.supporting}>{supportingText}</p>}
        </div>
      </div>
    );
  }

  // Row types — [check?] [leading] [content] [check?]
  return (
    <div {...rootProps}>
      {checkboxPosition === 'left' && control}
      {leading}
      <div className={styles.content}>
        {titleRow}
        {supportingText && <p className={styles.supporting}>{supportingText}</p>}
      </div>
      {checkboxPosition === 'right' && control}
    </div>
  );
}
