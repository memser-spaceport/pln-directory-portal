import type { HTMLAttributes } from 'react';
import type { AvailabilityStatus } from '@components/MemberCard';
import type { BadgeSize } from '@components/Badge';

export interface MemberProfileCardProps extends HTMLAttributes<HTMLElement> {
  name: string;
  role?: string;
  company?: string;
  location?: string;
  tags?: string[];
  /** Size of the tag badges. Defaults to 'sm'. */
  tagSize?: BadgeSize;
  avatar?: string;
  availability?: AvailabilityStatus;
  href?: string;
}
