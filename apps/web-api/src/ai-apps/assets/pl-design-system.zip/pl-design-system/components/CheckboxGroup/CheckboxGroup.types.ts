import type { HTMLAttributes, ReactNode } from 'react';

// Selectable rows / cards that wrap a Checkbox control.
//
//   Basic medium / Basic small → 'basic' (+ size 'md' | 'sm')
//   With Icon                  → 'with-icon'   (provide `icon`)
//   With Logo                  → 'with-logo'   (provide `icon`/logo node)
//   Avatar                     → 'avatar'      (provide `avatarName` / `avatarSrc`)
//   With Image                 → 'with-image'  (provide `image`)
//   Card                       → 'card'        (pricing card: `price`, `priceCaption`)

export type CheckboxGroupType =
  | 'basic'
  | 'with-icon'
  | 'with-logo'
  | 'avatar'
  | 'with-image'
  | 'card';

export type CheckboxGroupSize = 'sm' | 'md';

export type CheckboxPosition = 'left' | 'right';

export interface CheckboxGroupProps
  extends Omit<HTMLAttributes<HTMLLabelElement>, 'onChange'> {
  type?: CheckboxGroupType;
  /** Row height for the 'basic' type (Basic medium / Basic small). Default 'md'. */
  size?: CheckboxGroupSize;
  /** Which side the checkbox sits on. Default 'right'. */
  checkboxPosition?: CheckboxPosition;

  /** Controlled selected state. */
  checked?: boolean;
  /** Uncontrolled initial state. */
  defaultChecked?: boolean;
  /** Selection change handler. */
  onChange?: (checked: boolean) => void;
  disabled?: boolean;

  /** Primary label text. */
  label: ReactNode;
  /** Secondary description line under the label. */
  supportingText?: ReactNode;
  subLabel?: ReactNode;
  badge?: ReactNode;
  info?: boolean;

  /** Leading visual for 'with-icon' / 'with-logo'. */
  icon?: ReactNode;
  /** For 'avatar' type — forwarded to the Avatar component. */
  avatarName?: string;
  avatarSrc?: string;
  /** For 'with-image' type — thumbnail URL. */
  image?: string;

  /** 'card' type — large price string, e.g. "$199". */
  price?: ReactNode;
  /** 'card' type — caption next to price, e.g. "yearly". */
  priceCaption?: ReactNode;

  id?: string;
}
