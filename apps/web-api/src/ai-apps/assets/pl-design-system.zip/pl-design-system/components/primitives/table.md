# Table

---

## Read-made Table (`17260:61462`)

Full composed tables — start here when a stock layout fits.

- **Property 1**: Team members, Orders, Files uploaded, Cash Out Transactions, Leaderboard

---

## Table header (`14938:29415`)

- **Type**: Default, Disabled, Empty

---

## Table Cell (`14938:8436`)

Primitive cells for custom table layouts. Each combines:

- **Background**: White, Light gray
- **State**: Default, Hover, Active

See also: [table-cells.md](./table-cells.md) for usage guidance.

---

## Rules

- Prefer **Read-made Table** when the scenario matches (members, orders, files, transactions, leaderboard).
- Compose custom tables only from **Table header** + **Table Cell** instances.

---

## AI instruction

```
```
