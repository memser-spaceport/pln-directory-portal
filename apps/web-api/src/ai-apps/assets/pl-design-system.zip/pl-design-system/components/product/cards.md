# Cards Component

---

## Purpose

---

## Card Groups on This Page

### Focus Area Cards

**Variants (Property 1):** Card Focus Area 1–5

---

### Member Cards

- `Member Card Desktop` — 289×236px instance
- `Member Card Mobile` — 176×138px instance

**`MemberProfileCard` implementation (Figma node 27033:87295):**

- **Banner** — grey gradient band, white at top fading to `--transparent-dark-8` at the bottom (slate wash per DESIGN.md §7, never brand). The avatar sits **inside** the band, centered; decorative concentric rings are clipped to the band (`overflow: hidden`).
- **Avatar** — `size="2xl"` (64px), circle, centered within the banner (not overlapping/spilling below it).
- **Availability pill** — straddles the banner/content boundary. **Text-only** (no icon). `available` reads brand-blue (`--transparent-brand-6` fill, `--border-brand-subtle` border, `--foreground-brand-primary` text); `booked` → warning; `unavailable` → neutral.
- **Name** — `label-lg`, **Medium (500)** weight, `--foreground-neutral-primary`.
- **Company + role** — stacked on two lines, **company first**, centered, `label-sm` regular, `--foreground-neutral-secondary` (no inline `·` separator).
- **Location** — map-pin icon (16px) + text, `label-xs`, `--foreground-neutral-secondary`.
- **Tags** — `Badge color="gray" styleType="light"`; size via the `tagSize` prop (**default `lg`**).

Use `MemberProfileCard` for hero/discovery surfaces; `MemberCard` for dense lists.

---

### Team Cards

- `Team Card Desktop` — 289×269px instance
- `Team Card Mobile` — 176×186px instance

---

### Homepage Cards

**Variants (Property 1):** Card Investor, Card OH, Card Demo Day
Size: 390px wide, 88px h

---

### Updates / Notification Cards

**Variants (Property 1):**
- DD 1 Notification
- DD 2 Notification
- Events 1 Notification
- Events 2 Notification
- Forum 1–4 Notification
- OH Notification

---

### Demo Day Landing Page Cards

**Variants:**
- PL DD Upcoming
- PL DD Reg Open
- PL DD Active
- Partner DD Reg Open
- Partner DD Active
- Card Completed DD

**Variants:** PLDD Upcoming, Partner DD Upcoming, Completed DD

---

### Jobs Cards

**Property 1:** Default, Expanded

---

### Card Topic (Founder Guides / Forum)

**Property 1:** Default, Hover, Disabled, Request Topic
Size: 286×229px

---

### Office Hours Cards

**Property 1:** Team, Member

---

### Comments

**Desktop Property 1:** Comments Empty, Comments Typing, Comments Filled, Comments Published (1), Comments Published (7)
**Mobile includes:** @mention typing state

---

### Deals Cards

- `Card Deals Default` (desktop 900×174px, mobile 400×185px)
- Frame `27033:87472` — "Deals Empty": Card Empty, Card Filters Empty
- Frame `27033:86359` — Sorting controls (desktop + mobile)

---

### Team Fundraising Cards

**Property 1:** Card Large, Card Large Empty, Card Large Empty Founders, Card Small

**Property 1:** Investors, Founders

---

### Forum Posts

- `Forum Post Desktop` — 852×182px instance
- `Forum Post Mobile` — 368×206px instance

---

### Badge OH (Availability)

**Status:** Available to connect, Frequently Booked, Not available

Rendered as a **text-only** pill (no icon) on `MemberProfileCard`. The `available` state uses brand-blue — a deliberate departure from traffic-light convention (`--transparent-brand-6` fill, `--border-brand-subtle` border, `--foreground-brand-primary` text), not green.

---

### Card News

- `Card News` — 594×192px instance

---

## Usage Rules

1. Use `Member Card Desktop` / `Member Card Mobile` for member directory grids
2. Use `Updates Desktop` for homepage and profile activity feeds
4. Use `Card OH Desktop/Mobile` for office hours entries
5. Use `Card Jobs Desktop/Mobile` with Expanded variant for full job post view
6. Always use the `Deals Empty` variant when no deals are available for current filters
7. Use `Badge OH` for availability status labels on Member and Team cards

---

## AI Instructions

- Select the specific card group (Members, Teams, Forum, Deals, etc.) by frame name
- For comments, use the Comments frames — never build custom comment UIs
- Preserve Desktop/Mobile variant pairs — never use desktop card in a mobile layout
- Never create new card layouts; use the established component types
