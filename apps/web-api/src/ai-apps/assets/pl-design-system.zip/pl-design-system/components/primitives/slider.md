# Slider / Range

---

## Basic Slider (`14816:4878`)

- **Control**: 25%, 50%, 75%, 100%
- **Weight**: Bold (10px tall track), Thin (4px tall track)

---

## Double Slider / range (`14805:4669`)

- **Left Control** / **Right Control**: Combined positions from 0%–25% through 75%–100% (full matrix in file)
- **Weight**: Bold, Thin

---

## _BaseSliderControl (`14778:46719`)

- **Color**: Color, Light
- **Icon**: True, False
- **Size**: Medium (24×24), Small (18×18)

---

## _BaseLineGraph (`14778:45136`)

Used as optional track / analytics context behind or near sliders.

- **Type**: Thin Line, Bold Line, Thin Line 02
- **Active**: true, false

---

## Rules

- Match **Weight** (Bold vs Thin) to the surrounding UI density.

---

## AI instruction

```
```
