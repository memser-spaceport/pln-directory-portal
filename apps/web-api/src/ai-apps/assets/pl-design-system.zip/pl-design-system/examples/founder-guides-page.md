# Founder Guides Page

Layout composition: Sidebar + List or Centered Content

---

## Purpose

Resource library for founders. Guides are organized by category and topic.

---

## Layout

```
Header & Nav (full width)
↓
[Category sidebar] | [Search bar]
                     [Featured guide (hero card)]
                     [Guides article list]
                     [Pagination]
```

---

## Components used

| Element | Component |
|---|---|
| Header | `Header & Nav` |
| Category sidebar | `Sidebars & Bottom Sheets` — Founder Guides variant |
| Search | `Regular Search Input` |
| Featured guide | `Founder Guides Cards` (hero variant, if exists) |
| Guide cards | `Founder Guides Cards` |
| Tags | `Badges & Tags` |
| Pagination | `Pagination` |
