# Page Examples

Page examples are **structural references only**. They show how components and layout patterns are assembled into complete pages.

---

## Home Page

Layout composition: Full Width + Stack

**Sections (approximate):**
- Header & Nav
- Hero / Featured section (full width)
- Featured Focus Areas (grid of Focus Area Cards)
- Recent Updates (horizontal carousel or grid of Updates Cards)
- Featured Teams (grid of Team Cards)
- Recent Forum posts (list of Forum Cards)
- Featured Deals (grid of Deals Cards)
- CTA section

**Notes:**
- Use canonical Header & Nav
- All cards use their canonical product card components
- Do not compose custom hero sections — use canonical card/banner components

---

## Team Page (Team Profile)

Layout composition: Detail / Single Focus

**Sections:**
- Header & Nav
- Team hero (logo, name, description, member count, tags)
- Team members grid (Member Cards or Avatar list)
- About / Details section
- Related teams or focus areas

---

## Members Page (Member Directory)

Layout composition: Sidebar + Grid

**Sections:**
- Header & Nav
- Search + filter controls (canonical Search Input + Sidebar)
- Directory grid (Member Cards)
- Pagination

**Notes:**
- Sidebar uses canonical `Directory filter` sidebar variant
- Member cards use canonical `Directory Member Cards`

---

## Forum Main Page

Layout composition: Sidebar + List

**Sections:**
- Header & Nav
- Category navigation sidebar (or tabs)
- Forum post list (Forum Cards)
- Pinned posts at top
- Create post button (canonical Button)
- Pagination

---

## Deals Main Page

Layout composition: Sidebar + Grid

**Sections:**
- Header & Nav
- Search + filter sidebar (Deals filter variant)
- Deals card grid (Deals Cards)
- Pagination

---

## Demo Day Page

Layout composition: Sidebar + Grid or Full Width

**Sections:**
- Header & Nav
- Cohort filter sidebar or tab navigation
- Demo Day card grid (Demo Day Cards)
- Featured / hero cohort section
- Pagination

---

## Founder Guides

Layout composition: Sidebar + List or Centered Content

**Sections:**
- Header & Nav
- Category sidebar navigation
- Guides article list (Founder Guides Cards)
- Featured guide (hero card)
- Pagination

---

## Job Board

Layout composition: Sidebar + Grid or Sidebar + List

**Sections:**
- Header & Nav
- Filter sidebar (Job Board filter variant)
- Job listing cards (Jobs Cards)
- Pagination

---

## Modal Examples

**Purpose:** Reference for when and how modals appear in the system.

**Example modals:**
- Delete confirmation dialog
- Invite member dialog
- Quick view — member profile preview
- Apply to job dialog

**Rules:**
- All modal examples use canonical Modal overlay
- Content inside modal uses canonical form and button components

---

## Drawer Examples

**Purpose:** Reference for when and how drawers appear.

**Example drawers:**
- Member detail panel (right drawer)
- Deal detail panel (right drawer)
- Settings panel
- Mobile filter panel (bottom sheet)

**Rules:**
- All drawer examples use canonical Drawer or Bottom Sheet component
- Content inside drawer uses canonical components
